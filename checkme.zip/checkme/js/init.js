// сделаем данные задачи глобальными

		var task_data = null;



		
		// Функция checkme_load_task загружает с сервера данные по заданию и возвращает объект процесса.

		function checkme_load_task(id,config){

			var checkme_request = jQuery.getJSON("http://localhost:8888/checkme/test.php", {
			                    
				jsonp : true,
				jsonpCallback: 'jsonCallback',
				dataType: 'json',
				id: id,

					success: function(){

						checkme_display_status("loading");

					}

			});

			// обработка событий запроса

			// запрос провален

			checkme_request.fail(function(){ checkme_display_status("fail");});

			// запрос с ошибкой 

			checkme_request.error(function(){ checkme_display_status("error");});

			// запрос выполнен

			checkme_request.done(function(){ checkme_display_status("done");});

			// запрос завершен

			checkme_request.complete(function(data){ 

				task_data = checkme_request.responseJSON; 

			});

			return checkme_request;

		}


		// Функция checkme_init_ui раскладывает полученные данные по полочкам интерфейса


		function checkme_init_ui(){





		}


		

		