
var checkme_mode = "html";

var checkme_user= {id:1,"title":"Глеб Кушедов","avatar":"",role:10}

var checkme_lang = "ru";

var checkme_server = {'php':"server.php"};