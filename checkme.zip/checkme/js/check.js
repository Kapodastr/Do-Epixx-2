function checkme_get_task(task_id){

	if((typeof task_data ==undefined) || (task_data == null)){
		console.log("ошибка при зарузке данных задания");
		checkme_display_status("nocheck");
		return 0;
	}

	// определение условий запроса 

		// инициализируем переменные задачки

		// здесь через foreach проверяем условия

		var expression = task_data["check"][0]["code"];

		

	};

function check_single(rule){

	var result = $("#preview").contents();

	if(eval(rule["code"])){

			return true;

		}else{

			return false;

	}

}

function checkme_check(e){ 

	e.preventDefault();
    updatePreview();

    // Функция проверяет, выполнены ли все условия и сообщает об этом

	task_data['check'].forEach(function(rule,i){

		// дописываем массиву с правилами информацию о том, что было выполнено
		 
		task_data['check'][i]['done'] = check_single(rule);

		//alert(task_data['check'][i]['done']);

	});

	checkme_check_results(); // выведем результаты в симпатичном модальном окне

}


function checkme_check_results(){

	$(".alert-box").html("");

	task_data['check'].forEach(function(rule,i){

		if(rule['done']){status="Выполнено";}else{status="Не выполнено";}

		$(".alert-box").append("<p class='task-report'> "+status+": "+rule['title']+"</p>");

	})

	$(".alert-box").slideDown();

	 


}

function checkme_php(){

	alert("ok but i will check it later");

	$("#preview").contents().html("<html>234324</html>");
	
	$.ajax({
    url: 'server.php',             // указываем URL и
    data: {"code":$("#code").val()},
    dataType : "text",                     // тип загружаемых данных
    success: function (data) { // вешаем свой обработчик на функцию success
        
        console.log(data);
    }               
});

}

// Модальное окно

// function modal_hide(){

// 	$("#modal").slideUp();

// }

// function checkme_window_show(){

		

// }



