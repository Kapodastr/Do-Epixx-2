
function checkme_get_status(status){

	var status_explained = {

		"loading":"Данные загружаются",
		"error":"Произошла ошибка",
		"done":"Данные загружены",
		"fail":"Данные не удалось загрузить",	
		"nocheck":"Инструкции по проверке задания некорректны",					

	}

	return status_explained[status];

}

// Получим и покажем новый статус

function checkme_display_status(status){

	$("#status").html(checkme_get_status(status));

}

      
function updatePreview() {

    var previewFrame = document.getElementById('preview');
    var preview =  previewFrame.contentDocument ||  previewFrame.contentWindow.document;
    preview.open();
    preview.write(editor.getValue());
    preview.close();
        
}


function checkme_update_ui(){

	// task_data - глобальная переменная, которая хранит в себе описание задания

	$(".task-title").html(task_data["task_title"]);
	$(".module-title").html(task_data["module_title"]);
	$("#status").html(task_data["task_briefing"]);

}



/*   а сейчас мы будем долго и вдумчиво описывать управление лайаутом    */




function checkme_layout(layout){

	 


	if(layout=="code"){

		$(".CodeMirror").css("transition","500ms all").css("width","100%");
		$(".checkme_preview,.checkme_example").css("transition","500ms all").css("width","0%");

	}

	if(layout=="preview"){

		$(".CodeMirror").css("transition","500ms all").css("width","0%");
		$(".checkme_preview,.checkme_example").css("transition","500ms all").css("width","100%");

	}	

	if(layout=="split"){

		$(".CodeMirror").css("transition","500ms all").css("width","50%");
		$(".checkme_preview,.checkme_example").css("transition","500ms all").css("width","50%");

	}	

}



