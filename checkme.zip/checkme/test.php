<?

if(isset($_REQUEST['id'])){

	$id = $_REQUEST['id'];

}else{

	http_response_code(404);

	exit;

}

?>{
    "status":"200",
    "id": <?php echo $id; ?>,
    "track": 33,
    "track_title":"Название трека",
    "start_html":"Начните вводить html здесь",
    "start_сss":"Начните вводить css здесь",    
    "task_title": "Котики и солнышки-2",
    "task_briefing": "Расположите в ряду <b>.row </b> три колонки <b>.column </b> рядом с помощью float",    
    "descripion": "Используйте флексбоксы, чтобы правильно расположить колонки",
    "check":[
    	{"title":"Добавьте правила","code":"$(result).find(\"div\").length==4"}

    ]
    
  }
